package com.sumeet.holu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HoluApplicationTests {

	@Test
	void contextLoads() {
	}

}
