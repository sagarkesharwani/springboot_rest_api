package com.sumeet.holu.services;
import java.util.*;

import com.sumeet.holu.entities.Employee;
import com.sumeet.holu.entities.Visitors;
public interface VisitorService {
	

	public List<Visitors>getVisitors();
	
	public void addvisitor(Visitors visitor);
	
	public Visitors getVisitorbyid(int id);

	public Visitors delVisitorbyid(int id);
	
	public Visitors updateVisitorbyid(Visitors visitor);
	
	public void addvisitors(List<Visitors> lists);
	
	public void deletevisitors(List<Visitors>l);
	
	public List<Visitors> getvisitorbyemployee(String emp);
	
	public List<Visitors> getvisitorbylocation(String loc);
	
	public int getvisitorcountbyemployee(String loc);
	
	public int getvisitorcountbylocation(String loc);

	
	
}

