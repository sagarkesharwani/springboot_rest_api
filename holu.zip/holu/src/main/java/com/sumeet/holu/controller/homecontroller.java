package com.sumeet.holu.controller;


import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.sumeet.holu.entities.Visitors;
import com.sumeet.holu.entities.Employee;
import com.sumeet.holu.services.VisitorService;

import jakarta.servlet.http.HttpServletResponse;


@RestController
public class homecontroller {
	@Autowired
	private VisitorService visitorservice;
	
	@GetMapping("/home")
	public String home() {
		return "home";
	}
	
	@GetMapping("/visitors")
	public List<Visitors> getVisitors() {
		return this.visitorservice.getVisitors();
	}
	
	@RequestMapping(method=RequestMethod.POST,value="/visitor")
	public void addvisitors(@RequestBody Visitors visitor) {
		visitorservice.addvisitor(visitor);
	}
	
	@RequestMapping(value = "/visitor/{id}")
	public Visitors getVisitorbyid(@PathVariable int id) {
	    return visitorservice.getVisitorbyid(id);
	}
	
	@RequestMapping(method=RequestMethod.DELETE,value = "/visitor/{id}")
	public Visitors delVisitorbyid(@PathVariable int id) {
	    return visitorservice.delVisitorbyid(id);
	}

	@RequestMapping(method=RequestMethod.PUT,value = "/visitor")
	public Visitors updaVisitorbyid(@RequestBody Visitors visitor) {
	    return visitorservice.updateVisitorbyid(visitor);
	}

	@RequestMapping(method=RequestMethod.POST,value="/visitors")
	public void addvisitors(@RequestBody List<Visitors> lists) {
		visitorservice.addvisitors(lists);
	}
	
	@RequestMapping(method=RequestMethod.DELETE,value="/visitors/")
	public void deletevisitors(@RequestBody List<Visitors>l) {
		visitorservice.deletevisitors(l);
	}
	
	@RequestMapping(method=RequestMethod.GET,value = "/employee/{empo}")
	public List<Visitors> getvisitorbyemploye(@PathVariable String empo) {
		return visitorservice.getvisitorbyemployee(empo);
	}
	
	@RequestMapping(method=RequestMethod.GET,value = "/visitors/location/{empo}")
	public List<Visitors> getvisitorbylocation(@PathVariable String empo) {
		return visitorservice.getvisitorbylocation(empo);
	}
	
	@RequestMapping(method=RequestMethod.GET,value = "/visitorcount/{empo}")
	public int getvisitorcountbyemployee(@PathVariable String empo) {
		return visitorservice.getvisitorcountbyemployee(empo);
	}
	

	@RequestMapping(method=RequestMethod.GET,value = "/visitorcountbyloc/{empo}")
	public int getvisitorcountbylocation(@PathVariable String empo) {
		return visitorservice.getvisitorcountbylocation(empo);
	}
	

	
	@RequestMapping("/downloadCsv")
	public void downloadCsv(HttpServletResponse response) throws IOException {
		try {
			response.setContentType("text/csv");
			response.setHeader("Content-Disposition", "attachment; filename-users.csv");
			 // write to CSV file //
			ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(),CsvPreference.STANDARD_PREFERENCE);
			String[]  headings  ={"id", "name", "address", "employee","date","location"};
			String[] pojoclassPropertyName = {"id", "name", "address", "employee","date","location"};
			csvWriter.writeHeader(headings);
			
			List<Visitors>lis= visitorservice.getVisitors();
			if(null!=lis && !lis.isEmpty()) {
				for(Visitors c:lis) {
					csvWriter.write(c,pojoclassPropertyName);	
				}
			}
			csvWriter.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		System.out.println("csv report downloaded successfully");
	}


	
}
