package com.sumeet.holu.entities;
import java.util.*;
import com.sumeet.holu.entities.Employee;

public class Visitors {
	
	private int id;
	private String name;
	private String address;
	public Employee employee;
	private Date date;
	private String location;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Employee getEmployee() {
		return employee;
	}
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "Visitors [id=" + id + ", name=" + name + ", address=" + address + ", employee=" + employee + ", date="
				+ date + "]";
	}
	public Visitors(int id, String name, String address, Employee employee, Date date,String location) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.employee = employee;
		this.date = date;
		this.location=location;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Visitors() {
		super();
		// TODO Auto-generated constructor stub
	}
		
}
