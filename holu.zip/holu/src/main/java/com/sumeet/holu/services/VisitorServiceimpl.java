package com.sumeet.holu.services;

import org.springframework.stereotype.Service;
import com.sumeet.holu.entities.Visitors;
import com.sumeet.holu.entities.Employee;
import java.util.*;


@Service
public class VisitorServiceimpl implements VisitorService {

	List<Visitors> list;
	List<Visitors>visited;
	List<Visitors>vist= new ArrayList<>();
	Date date=new Date();
	

	public VisitorServiceimpl() {
			list =new ArrayList<>();
			list.add(new Visitors(101,"Sagar Kesharwani","Tarangan Society",new Employee("sanjana"),date,"mumbai"));
			list.add(new Visitors(102,"Sumeet Singh","Arihant society",new Employee("shivani"),date,"goregaon"));
			list.add(new Visitors(103,"Nitish xyz","Powai,mumbai",new Employee("rohini"),date,"mumbai"));
			
		}
		
		@Override
		public List<Visitors> getVisitors() {
			// TODO Auto-generated method stub
			return list;
		}
		
		
		@Override
		public void addvisitor(Visitors visitor) {
			// TODO Auto-generated method stub
			list.add(visitor);
		}

		@Override		
			public Visitors getVisitorbyid(int id) {
					for(Visitors visitor : list) {
						if(visitor.getId()==id) {
							return visitor;
						}
					}
					return null;
			}
		@Override		
		public Visitors delVisitorbyid(int id) {
				for(Visitors visitor : list) {
					if(visitor.getId()==id) {
						list.remove(visitor);
					}
				}
				return null;

		}
		
		@Override		
		public Visitors updateVisitorbyid(Visitors visitor) {
				for(Visitors v : list) {
					int u=v.getId();
				if(u==visitor.getId()) {
					int f=list.indexOf(v);
					list.set(f, visitor);
					}
				}
				return null;
		}
		
		
		@Override
		public void addvisitors(List<Visitors> lists) {
			list.addAll(lists);
			}
		
		@Override
		public void deletevisitors(List<Visitors>l) {
			for(Visitors v : l) {
					for(Visitors g:l) {
						if(g.getId()==v.getId()) {
						list.remove(g);
						}
					}
				}
			}
		
		
		
		@Override
		public List<Visitors> getvisitorbyemployee(String empo) {
			visited =new ArrayList<>();
			for(Visitors m:list) {
				String p=m.getEmployee().getName();
				if(p.equalsIgnoreCase(empo)) {
				visited.add(m);
				System.out.println(empo);
//				System.out.println(m.getEmployee().getName());
			}
		}
			return visited;
		}
		

		@Override
		public List<Visitors> getvisitorbylocation(String loc) {
			for(Visitors m:list) {
				String p=m.getLocation();
				if(p.equalsIgnoreCase(loc)) {
				vist.add(m);
			}
		}
			return vist;
		}
		
		@Override
		public int getvisitorcountbyemployee(String empo) {
			int count=0;
			for(Visitors m:list) {
				if(m.getEmployee().getName().equalsIgnoreCase(empo)) {
				count++;
			}			
				}
			return count;
		}
		
		@Override
		public int getvisitorcountbylocation(String empo) {
			int vount=0;
			for(Visitors m:list) {
				if(m.getLocation().equalsIgnoreCase(empo)) {
				vount++;
				}
			}
			return vount;
		}
		
		
		
		
}
