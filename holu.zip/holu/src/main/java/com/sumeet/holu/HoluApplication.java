package com.sumeet.holu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HoluApplication {

	public static void main(String[] args) {
		SpringApplication.run(HoluApplication.class, args);
		
		System.out.print("hello");
		
	}
}
